from django.apps import AppConfig


class Dja1Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'dja1'
